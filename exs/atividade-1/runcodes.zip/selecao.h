#ifndef SELECAO_H
#define SELECAO_H
void selecao(int *vetor, int n);
#endif