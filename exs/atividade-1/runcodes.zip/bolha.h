#ifndef BOLHA_H
#define BOLHA_H
void bolha(int *vetor, int n);
#endif